<!DOCTYPE html>
<html>
<body>
<form method="post">
    <h2>Enter A:-</h2>
    <input type="number" name="number1">
    <h2>Enter B:-</h2>
    <input type="number" name="number2">
    <br><br>
    <input type="submit" name="addition" value="Addition">
    <input type="submit" name="sub" value="Subtraction">
    <input type="submit" name="mul" value="Multiplication">
    <input type="submit" name="div" value="Division">
</form>
<?php
if (isset($_POST['addition']))
{
    $a = $_POST['number1'];
    $b = $_POST['number2'];
    $sum = $a + $b;
    echo "$a + $b = $sum";
} 
if (isset($_POST['sub']))
{
    $a = $_POST['number1'];
    $b = $_POST['number2'];
    $sub = $a - $b;
    echo "$a - $b = $sub";
} 
if (isset($_POST['mul']))
{
    $a = $_POST['number1'];
    $b = $_POST['number2'];
    $product = $a * $b;
    echo "$a * $b = $product";
} 
if (isset($_POST['div']))
{
    $a = $_POST['number1'];
    $b = $_POST['number2'];
    $division = $a / $b;
    echo "$a / $b = $division";
} 
?>  
</body>
</html>