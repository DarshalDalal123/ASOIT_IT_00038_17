<!DOCTYPE html>
<html>
<body>

<?php
$c = 1;
switch ($c) {
  case 1:
    echo "Your favorite color is red!";
    break;
  case 2:
    echo "Your favorite color is blue!";
    break;
  case 3:
    echo "Your favorite color is green!";
    break;
  default:
    echo "Your favorite color is neither red, blue, nor green!";
}
?>
 
</body>
</html>
