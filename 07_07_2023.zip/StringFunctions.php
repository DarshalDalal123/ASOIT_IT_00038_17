<!DOCTYPE html>
<html>
<body>

<?php
echo strlen("Hello world!");
echo "<br>";
echo str_word_count("Hello world!");
echo "<br>";
echo strrev("Hello world!");
echo "<br>";
echo strpos("Hello world!", "world");
echo "<br>";
echo str_replace("world", "Dolly", "Hello world!"); //str_replace(old word,new word,string)
?> 
 
</body>
</html>
